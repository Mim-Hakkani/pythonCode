#show the addition,substraction,multiplicataion all mathematical calculation using variable
a=50;
b=25;
print("The Addition is : ",a+b)
print("The Substraction is : ",a-b)
print("The Multiplication is : ",a*b)
print("The division is : ",a/b)
print("The rest of Division is : ",a%b)
print("The power is : ",a**b)


