#Calculate the triangle of the area

a=int(input("Enter The value 1 : "));
b=int(input("Enter The Value 2: "));
area = 0.5*a*b;
print("The Area Of tringale is : ",area);