# Calculate the min,max,abs,sqrt,pow,round,celling,floor bu using built in function
from math import*
num1 = int(input("Enter the number 1: "));
num2 = int(input("Enter the number 2: "));
num3 = int(input("Enter the number 3: "));
# show Minimum number
print("The Minimum number is : ",min(num1,num2));
#show the maximum number
print("The Maximum number is : ",max(num1,num2));

#show the power number
print("The power of the two number is : ",pow(num1,num2));

#show the Absulate number
print("The absulate number is : ",abs(num3));

#show the sqrt number
print("The sqrt number is : ",sqrt(abs(num3)));