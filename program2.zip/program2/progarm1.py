#show my first name and starting the name of allah
print("About My Information ")
print("------------------")
print("Bismillah Hir rahmanir rahim.")
print("Golam Hakkani Mim")
print("Pabna university of science and technology")
print("roll number is : 150132")