#Calculate the triangle of the area

a=int(input("Enter The value 1 : "))
area = 3.14156*a*a
print("The Area Of Circle is : ",area)