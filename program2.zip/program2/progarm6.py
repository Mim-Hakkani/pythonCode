#show the addition,substraction,multiplicataion all mathematical calculation usning user input


a=input("Enter The Number : ")
b=input("Ener Another Number : ")
sum=int(a)+int(b)
print("The Addition is : ",int(a)+int(b))
print("The Substraction is : ",int(a)-int(b))
print("The Multiplication is : ",int(a)*int(b))
print("The division is : ",int(a)/int(b))
print("The rest of Division is : ",int(a)%int(b))
print("The power is : ",int(a)**int(b))



