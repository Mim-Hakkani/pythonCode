#show the pyramid of misorrr
'''
 *
 **
 ***
'''

print("The Figure Of The Piramid Is : ")
print(" ")
print(" * ")
print(" * *")
print(" * * *")
print(" * * * *")

print(" ")
print("The Reverse Piramid Is : ")

print(" ")
print(" * * * *")
print(" * * *")
print(" * * ")
print(" *")