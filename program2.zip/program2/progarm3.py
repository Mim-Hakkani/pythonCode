#Show the Baclslases character in python programming
print("Hi !\nI Am Golam Hakkani Mim\n\tAnd You ?\nI Am Kibria Jim")
