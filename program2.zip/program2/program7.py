#Calculate the rectriangle of the area

a=int(input("Enter The value 1 : "));
b=int(input("Enter The Value 2: "));
area = a*b;
print("The Area Of ractangle is : ",area);