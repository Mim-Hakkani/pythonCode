#show the addition,substraction,multiplicataion all mathematical calculation without variable

print("The Addition is : ",100+10)
print("The Substraction is : ",100-10)
print("The Multiplication is : ",100*10)
print("The division is : ",100/10)
print("The rest of Division is : ",100%3)
print("The power is : ",2**3)


